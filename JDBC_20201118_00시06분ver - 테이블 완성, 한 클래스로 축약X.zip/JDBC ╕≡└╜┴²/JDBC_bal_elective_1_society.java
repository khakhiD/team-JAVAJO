import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//�ձ� 1�г� ��ȸ�� ����

public class JDBC_bal_elective_1_society {
    public static void main(String[] args) {

        Connection conn = null;

        try{
        	
            Class.forName("com.mysql.cj.jdbc.Driver");

            String url = "jdbc:mysql://localhost/test?characterEncoding=UTF-8&serverTimezone=UTC";
            //jdbc:mysql://~~~/����̸�, ����ǥ���ʹ� Ÿ���� ���� ������ ����. ������ ū�ϳ�.
           
            conn = DriverManager.getConnection(url, "root", "151106");
            //(, "�̸�", "��й�ȣ")
            System.out.println("<���� ����>\n");
            
            String qu1 = "select * from ��1�г��ȸ������";
			Statement st1 = conn.createStatement();
			ResultSet rs1 = st1.executeQuery(qu1);
			
			while(rs1.next()) {
				int id = rs1.getInt("id");
				int grade = rs1.getInt("grade");
				String name = rs1.getString("classname");
				int credit = rs1.getInt("score");
				int number_of_people = rs1.getInt("personnumber");
				String professor = rs1.getString("professor");
				String building = rs1.getString("place");
				int classroom_1 = rs1.getInt("cn1");
				int start_1 = rs1.getInt("start1");
				int end_1 = rs1.getInt("end1");
				int classroom_2 = rs1.getInt("cn2");
				int start_2 = rs1.getInt("start2");
				int end_2 = rs1.getInt("end2");	

				
				System.out.format("%d, %d, %s, %d, %d, %s, %s, %d, %d, %d, %d, %d, %d\n", 
						id, grade, name, credit, number_of_people, professor, building,
						classroom_1, start_1, end_1, classroom_2, start_2, end_2);

			}
			st1.close();
		}
        catch(Exception e) {
			System.err.println("�ӻ��ϳ�");
			System.err.println(e.getMessage());
		}
	}
}

