package javajo_project;

public class Main
{
	public static void main(String[] args)
	{
		new JVJFrame("");
	}
}
