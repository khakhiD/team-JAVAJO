package javajo_project;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.sun.tools.javac.Main;

import javax.swing.JLabel;
import javax.swing.BoxLayout;
import javax.swing.JSeparator;
import javax.swing.border.LineBorder;
import javax.swing.border.CompoundBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;

/* @Author : 신동호
 * Javajo Swing Container Structure
 */

public class JVJFrame extends JFrame
{
	ImageIcon icon;
	private final ButtonGroup gradeGroup = new ButtonGroup();
	private final ButtonGroup semesterGroup = new ButtonGroup();
	private JTextField creditsField;
	
	public JVJFrame(String str)
	{
		super(str);
		setBackground(Color.BLACK);
		Container c = getContentPane();
		
		/*
		 * <JVJPanel> JFrame과 같은 사이즈의 패널 컨테이너
		 * 사이즈는 JFrame과 같음
		 */
		JPanel JVJPanel = new JPanel();
		JVJPanel.setBounds(0,0,900,600);
		
		JPanel mainPanel = new JPanel();
		mainPanel.setBackground(Color.WHITE);
		mainPanel.setBounds(260, 0, 624, 561);
		mainPanel.setLayout(null);
		mainPanel.setBorder(null);
		mainPanel.setOpaque(true);
		
		// topPanel <시간표 생성하기> 이미지
		icon = new ImageIcon("D:\\KDY\\javajo_project\\src\\javajo_project\\images\\top_panel_bg.png");
		JPanel topPanel = new JPanel()
		{
			public void paintComponent(Graphics g)
			{
				g.drawImage(icon.getImage(), -1, 0, null);
			}
		};
		
		topPanel.setBackground(Color.RED);
		topPanel.setSize(624, 180);
		topPanel.setLayout(null);
		topPanel.setLocation(0,0);
		topPanel.setBorder(null);
		
		JPanel botPanel1 = new JPanel();
		botPanel1.setBackground(Color.WHITE);
		botPanel1.setLayout(null);
		botPanel1.setBounds(0,180,624,379);
		botPanel1.setBorder(null);
		
		mainPanel.add(botPanel1);
		
		/*
		 * <inputGuideLabel> 입력해주세요 부분
		 * 코드에는 폰트를 설정해서 했지만 추후에 이미지로 변경할 예정
		 * "에스코어 드림" 폰트 설치가 되어 있지 않으면 제대로 안보임 
		 */
		JLabel inputGuideLabel = new JLabel("아래의 항목을 입력해주세요");
		inputGuideLabel.setFont(new Font("에스코어 드림 5 Medium", Font.PLAIN, 20));
		inputGuideLabel.setBounds(85, 51, 248, 24);
		botPanel1.add(inputGuideLabel);
		
		/*
		 * <inputLabel> 입력 항목 텍스트 라벨 부분
		 * 학과, 학년, 학기, 학점 = 굴림, PLAIN, 12pt
		 */
		JLabel majorLabel = new JLabel("학과");
		majorLabel.setFont(new Font("굴림", Font.PLAIN, 12));
		majorLabel.setBounds(95, 100, 40, 20);
		botPanel1.add(majorLabel);
		
		JLabel gradeLabel = new JLabel("학년");
		gradeLabel.setFont(new Font("굴림", Font.PLAIN, 12));
		gradeLabel.setBounds(95, 145, 40, 20);
		botPanel1.add(gradeLabel);
		
		JLabel semesterLabel = new JLabel("학기");
		semesterLabel.setFont(new Font("굴림", Font.PLAIN, 12));
		semesterLabel.setBounds(95, 195, 40, 20);
		botPanel1.add(semesterLabel);
		
		JLabel creditsLabel = new JLabel("학점");
		creditsLabel.setFont(new Font("굴림", Font.PLAIN, 12));
		creditsLabel.setBounds(95, 245, 40, 20);
		botPanel1.add(creditsLabel);
		
		/*
		 * <separator> 구분선
		 * 옅은 회색으로 각 입력 항목 사이에 가로 구분선을 출력함
		 */
		JSeparator separatorLong = new JSeparator();
		separatorLong.setForeground(Color.LIGHT_GRAY);
		separatorLong.setBounds(76, 82, 440, 1);
		botPanel1.add(separatorLong);
		
		JSeparator separator1 = new JSeparator();
		separator1.setForeground(SystemColor.menu);
		separator1.setBounds(90, 130, 350, 1);
		botPanel1.add(separator1);
		
		JSeparator separator2 = new JSeparator();
		separator2.setForeground(SystemColor.menu);
		separator2.setBounds(90, 180, 350, 1);
		botPanel1.add(separator2);
		
		JSeparator separator3 = new JSeparator();
		separator3.setForeground(SystemColor.menu);
		separator3.setBounds(90, 230, 350, 1);
		botPanel1.add(separator3);
		
		JSeparator separator4 = new JSeparator();
		separator4.setForeground(SystemColor.menu);
		separator4.setBounds(90, 280, 350, 1);
		botPanel1.add(separator4);
		
		JComboBox majorCombo = new JComboBox();
		majorCombo.setFont(new Font("굴림", Font.PLAIN, 12));
		majorCombo.setModel(new DefaultComboBoxModel(new String[] {"컴퓨터공학","컴퓨터공학","컴퓨터공학"}));
		majorCombo.setBounds(155, 98, 152, 23);
		botPanel1.add(majorCombo);
		
		JRadioButton grade1_rdbtn = new JRadioButton("1학년");
		grade1_rdbtn.setFont(new Font("굴림", Font.PLAIN, 12));
		gradeGroup.add(grade1_rdbtn);
		grade1_rdbtn.setHorizontalAlignment(SwingConstants.CENTER);
		grade1_rdbtn.setBackground(Color.WHITE);
		grade1_rdbtn.setBounds(149, 144, 60, 23);
		botPanel1.add(grade1_rdbtn);
		
		JRadioButton grade2_rdbtn = new JRadioButton("2학년");
		grade2_rdbtn.setFont(new Font("굴림", Font.PLAIN, 12));
		gradeGroup.add(grade2_rdbtn);
		grade2_rdbtn.setHorizontalAlignment(SwingConstants.CENTER);
		grade2_rdbtn.setBackground(Color.WHITE);
		grade2_rdbtn.setBounds(213, 144, 60, 23);
		botPanel1.add(grade2_rdbtn);
		
		JRadioButton grade3_rdbtn = new JRadioButton("3학년");
		grade3_rdbtn.setFont(new Font("굴림", Font.PLAIN, 12));
		gradeGroup.add(grade3_rdbtn);
		grade3_rdbtn.setHorizontalAlignment(SwingConstants.CENTER);
		grade3_rdbtn.setBackground(Color.WHITE);
		grade3_rdbtn.setBounds(277, 144, 60, 23);
		botPanel1.add(grade3_rdbtn);
		
		JRadioButton grade4_rdbtn = new JRadioButton("4학년");
		grade4_rdbtn.setFont(new Font("굴림", Font.PLAIN, 12));
		gradeGroup.add(grade4_rdbtn);
		grade4_rdbtn.setHorizontalAlignment(SwingConstants.CENTER);
		grade4_rdbtn.setBackground(Color.WHITE);
		grade4_rdbtn.setBounds(341, 144, 60, 23);
		botPanel1.add(grade4_rdbtn);
		
		JRadioButton semester1_rdbtn = new JRadioButton("1학기");
		semester1_rdbtn.setFont(new Font("굴림", Font.PLAIN, 12));
		semesterGroup.add(semester1_rdbtn);
		semester1_rdbtn.setHorizontalAlignment(SwingConstants.CENTER);
		semester1_rdbtn.setBackground(Color.WHITE);
		semester1_rdbtn.setBounds(149, 194, 60, 23);
		botPanel1.add(semester1_rdbtn);
		
		JRadioButton semester2_rdbtn = new JRadioButton("2학기");
		semester2_rdbtn.setFont(new Font("굴림", Font.PLAIN, 12));
		semesterGroup.add(semester2_rdbtn);
		semester2_rdbtn.setHorizontalAlignment(SwingConstants.CENTER);
		semester2_rdbtn.setBackground(Color.WHITE);
		semester2_rdbtn.setBounds(213, 194, 60, 23);
		botPanel1.add(semester2_rdbtn);
		
		/* <credits> 학점 입력 부분
		 * 포커스 리스너로 초기값 "정수값"이라는 문자열을 표시하고 있다가,
		 * 사용자가 포커스를 주면 빈 문자열 ""을 출력하고 문자 색상을 검은색으로 변경
		 */
		creditsField = new JTextField();
		creditsField.addFocusListener(new FocusAdapter()
		{
			@Override
			public void focusGained(FocusEvent e)
			{
				creditsField.setText("");
				creditsField.setForeground(new Color(0,0,0));
			}
		});
		creditsField.setForeground(new Color(192, 192, 192));
		creditsField.setHorizontalAlignment(SwingConstants.RIGHT);
		creditsField.setText("정수값");
		creditsField.setFont(new Font("굴림", Font.PLAIN, 12));
		creditsField.setBounds(155, 245, 60, 21);
		botPanel1.add(creditsField);
		creditsField.setColumns(10);
		mainPanel.add(topPanel);
		
		/* <nextButton> 버튼
		 * 지금은 누르면 botPanel1을 안보이게끔 설정함
		 * botPanel2(강의 풀 선택, 공강선택, 점심시간 선택 패널)가 완성되면
		 * botPanel2가 보이게끔(setVisible(true)) 설정하도록 하면 됨 
		 */
		JButton nextButton = new JButton("다음");
		nextButton.setFont(new Font("굴림", Font.PLAIN, 12));
		nextButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				botPanel1.setVisible(false);
				// botPanel2.setVisible(true);
				
				Schedule [] complete_schedules;
				complete_schedules = new Schedule[1000];
				
				String userMajor = "";
				int userGrade = 0;
				int userSemester = 0;
				int userCredit = 0;
				
				userMajor = majorCombo.getSelectedItem().toString();
				
				if(grade1_rdbtn.isSelected())
					userGrade = 1;
				else if(grade2_rdbtn.isSelected())
					userGrade = 2;
				else if(grade3_rdbtn.isSelected())
					userGrade = 3;
				else if(grade4_rdbtn.isSelected())
					userGrade = 4;
				
				if(semester1_rdbtn.isSelected())
					userSemester = 1;
				else if(semester2_rdbtn.isSelected())
					userSemester = 2;
				
				userCredit = Integer.parseInt(creditsField.getText());
				
				Lecture [] requiredLec;		// 전공 필수 강의 DB
				Lecture [] selectionLec;	// 전공 선택 강의 DB
				Lecture [] balanceLiberal; 	// 균형 교양 강의 DB
				Lecture [] autonomyLiberal; // 자율 교양 강의 DB
				
				requiredLec = GetData.getDatabase("전공필수", userMajor, userGrade, userSemester);
				selectionLec = GetData.getDatabase("전공선택", userMajor, userGrade, userSemester);
				balanceLiberal = GetData.getDatabase("균형교양", userMajor, userGrade, userSemester);
				autonomyLiberal = GetData.getDatabase("자율교양", userMajor, userGrade, userSemester);
				
				// 사용자 입력값 예시
				Lecture [] userLec;
				userLec = new Lecture[16];
				userLec[0] = new Lecture("비주얼프로그래밍", 3, 35, "안귀임", "정보", 814, 29, 30, 810, 37, 38);
				userLec[1] = new Lecture("비주얼프로그래밍", 3, 35, "안귀임", "정보", 816, 25, 26, 810, 37, 38);
				userLec[2] = new Lecture("비주얼프로그래밍", 3, 35, "최병윤", "정보", 814, 3, 3, 814, 17, 18);
				userLec[3] = new Lecture("자료구조", 3, 50, "김진일", "정보", 811, 5, 6, 812, 19, 19);
				userLec[4] = new Lecture("자료구조", 3, 50, "김진일", "정보", 812, 11, 12, 811, 27, 27);
				userLec[5] = new Lecture("컴퓨터구조", 3, 50, "이문노", "정보", 811, 17, 17, 812, 34, 35);
				userLec[6] = new Lecture("컴퓨터구조", 3, 50, "이문노", "정보", 812, 14, 15, 812, 27, 27);
				userLec[7] = new Lecture("논리설계및실습", 3, 50, "이문노", "정보", 812, 21, 22, 815, 29, 30);
				userLec[8] = new Lecture("논리설계및실습", 3, 50, "이문노", "정보", 812, 21, 22, 815, 31, 32);
				userLec[9] = new Lecture("논리설계및실습", 3, 50, "김화선", "정보", 815, 2, 3, 815, 14, 15);
				userLec[10] = new Lecture("자바프로그래밍", 3, 33, "장시웅", "정보", 811, 9, 10, 816, 29, 30);
				userLec[11] = new Lecture("자바프로그래밍", 3, 33, "장시웅", "정보", 811, 9, 10, 817, 31, 32);
				userLec[12] = new Lecture("자바프로그래밍", 3, 33, "장시웅", "정보", 817, 23, 24, 817, 34, 35);
				userLec[13] = new Lecture("현대자본주의이해", 2, 24, "박태진", "상경", 512, 7, 8, 0, 0, 0);
				userLec[14] = new Lecture("문학과인생", 2, 20, "김도희", "1인", 504, 14, 15, 0, 0, 0);
				userLec[15] = new Lecture("기초수학", 3, 46, "류재칠", "정보", 615, 29, 30, 615, 33, 33);
				
				complete_schedules = MakeSchedule.makeSchedule(userMajor, userGrade, userSemester, userCredit, requiredLec, userLec);
			}
		});
		nextButton.setBounds(463, 324, 97, 23);
		botPanel1.add(nextButton);
		
		getContentPane().add(JVJPanel);
		JVJPanel.setLayout(null);
		JVJPanel.add(mainPanel);
		
		JPanel sidePanel = new JPanel()
		{
			Image sidePanel_bg = new ImageIcon("D:\\KDY\\javajo_project\\src\\javajo_project\\images\\sidePanel_bg.png").getImage();
			public void paint(Graphics g)
			{
				g.drawImage(sidePanel_bg, 0, 0, null);
			}
		};
		sidePanel.setBounds(0, 0, 260, 561);
		JVJPanel.add(sidePanel);
		sidePanel.setBackground(Color.WHITE);
		// 경계선 확인
		sidePanel.setBorder(null);
		sidePanel.setLayout(null);
		
		this.setSize(900,600);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);		// 프레임 크기 변경 불가능
	}
}